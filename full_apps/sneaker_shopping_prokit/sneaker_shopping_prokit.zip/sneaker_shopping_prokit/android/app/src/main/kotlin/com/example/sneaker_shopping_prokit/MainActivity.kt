package com.example.sneaker_shopping_prokit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
