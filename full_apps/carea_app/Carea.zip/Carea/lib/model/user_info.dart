class UserInfo {
  String userFullName;
  String userNickName;
  String userDateOfBirth;
  String userEmail;
  String userContactNumber;
  String userGender;
  String userImage;

  UserInfo(
    this.userFullName,
    this.userNickName,
    this.userDateOfBirth,
    this.userEmail,
    this.userContactNumber,
    this.userGender,
    this.userImage,
  );
}
