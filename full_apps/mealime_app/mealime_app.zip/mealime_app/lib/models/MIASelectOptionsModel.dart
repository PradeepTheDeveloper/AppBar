class MIASelectOptionsModel {

  String title;
  String? subtitle;
  bool? selected;

  MIASelectOptionsModel({required this.title,this.selected,this.subtitle});

}


