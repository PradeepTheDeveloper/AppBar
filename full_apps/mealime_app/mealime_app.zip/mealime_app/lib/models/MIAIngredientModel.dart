class MIAInstructionsModel{

  String title;
  List<String> subtitles;

  MIAInstructionsModel({required this.title,required this.subtitles});

}