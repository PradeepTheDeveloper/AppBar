package com.example.juber_car_booking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
