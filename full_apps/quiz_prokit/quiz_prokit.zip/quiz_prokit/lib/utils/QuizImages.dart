import 'package:quiz_prokit/utils/QuizConstant.dart';

const quiz_ic_communication = "$BaseUrl/images/quiz/quiz_ic_communication.png";
const quiz_ic_communication2 = "$BaseUrl/images/quiz/quiz_ic_communication2.png";
const quiz_ic_course1 = "$BaseUrl/images/quiz/quiz_ic_course1.png";
const quiz_ic_course2 = "$BaseUrl/images/quiz/quiz_ic_course2.png";
const quiz_ic_course3 = "$BaseUrl/images/quiz/quiz_ic_course3.png";
const quiz_ic_info = "$BaseUrl/images/quiz/quiz_ic_info.png";
const quiz_ic_java = "$BaseUrl/images/quiz/quiz_ic_java.png";
const quiz_ic_marketing = "$BaseUrl/images/quiz/quiz_ic_marketing.png";
const quiz_ic_notification = "$BaseUrl/images/quiz/quiz_ic_notification.png";
const quiz_ic_study1 = "$BaseUrl/images/quiz/quiz_ic_study1.png";
const quiz_ic_study2 = "$BaseUrl/images/quiz/quiz_ic_study2.png";
const quiz_ic_quiz1 = "images/quiz/quiz_ic_quiz1.png";
const quiz_ic_quiz2 = "images/quiz/quiz_ic_quiz2.png";
const quiz_ic_quiz = "images/quiz/quiz_ic_quiz.svg";
const quiz_ic_homes = "images/quiz/quiz_ic_home.svg";
const quiz_ic_user = "images/quiz/quiz_ic_user.svg";
const quiz_ic_facebook = "images/quiz/quiz_ic_facebook.svg";
const quiz_ic_google = "images/quiz/quiz_ic_google.svg";
const quiz_ic_mail = "images/quiz/quiz_ic_mail.svg";
const quiz_ic_twitter = "images/quiz/quiz_ic_twitter.svg";

const Quiz_ic_Grid = "images/quiz/quiz_ic_grid.png";
const Quiz_ic_List = "images/quiz/quiz_ic_list.png";
const quiz_img_People1 = "$BaseUrl/images/quiz/quiz_img_People1.jpg";
const quiz_img_People2 = "$BaseUrl/images/quiz/quiz_img_People2.png";

const quiz_ic_list1 = "images/quiz/quiz_ic_list1.png";
const quiz_ic_list2 = "images/quiz/quiz_ic_list2.png";
const quiz_ic_list3 = "images/quiz/quiz_ic_list3.png";
const quiz_ic_list4 = "images/quiz/quiz_ic_list4.png";
const quiz_ic_list5 = "images/quiz/quiz_ic_list5.png";
