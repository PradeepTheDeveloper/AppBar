
import 'package:shop_hop_prokit/utils/ShConstant.dart';

const bg_bottom_bar = "images/shophop/bg_bottom_bar.png";
const card = "images/shophop/card.png";
const chip = "images/shophop/chip.png";
const ic_app_background = "$BaseUrl/images/shophop/ic_app_background.png";
const ic_app_icon = "images/shophop/ic_app_icon.png";
const ic_reward_back = "images/shophop/ic_reward_back.jpg";
const ic_scratch_pattern = "images/shophop/ic_scratch_pattern.png";
const ic_walk = "images/shophop/ic_walk.jpeg";
const splash_bg = "images/shophop/splash_bg.png";
const splash_img = "images/shophop/splash_img.png";
const whitegradient = "images/shophop/whitegradient.png";

const ic_walk_1 = "images/shophop/ic_walk_1.png";
const ic_walk_2 = "images/shophop/ic_walk_2.png";
const ic_walk_3 = "images/shophop/ic_walk_3.png";
const ic_user = "images/shophop/ic_user.png";
const sh_user_placeholder = "images/shophop/user.png";
const sh_settings = "images/shophop/settings.png";
const sh_ic_heart = "images/shophop/ic_heart.svg";
const sh_ic_home = "images/shophop/ic_home.svg";
const sh_user = "images/shophop/ic_user.svg";
const sh_ic_cart = "images/shophop/ic_cart.svg";
const sh_radar = "images/shophop/radar.gif";
