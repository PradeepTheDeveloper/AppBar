class MLNewsVideoData {
  String? image;
  String? title;
  String? duration;

  MLNewsVideoData(this.image, this.title, this.duration);
}
