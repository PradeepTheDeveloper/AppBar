class MLVoucherData {
  String? image;
  String? title;
  String? date;

  MLVoucherData({this.image, this.title, this.date});
}
