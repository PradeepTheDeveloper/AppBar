class MLDepartmentData {
  String? image;
  String? title;
  String? subtitle;
  String? price;

  MLDepartmentData({this.image, this.title, this.subtitle, this.price});
}
