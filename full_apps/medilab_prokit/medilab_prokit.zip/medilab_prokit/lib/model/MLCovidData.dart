class MLCovidData {
  String? image;
  String? country;
  String? active;
  String? death;

  MLCovidData({this.image, this.country, this.active, this.death});
}
