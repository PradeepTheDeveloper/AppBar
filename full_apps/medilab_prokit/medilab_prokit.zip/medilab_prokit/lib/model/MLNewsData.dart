class MLNewsData {
  String? image;
  String? title;
  String? duration;

  MLNewsData({
    this.image,
    this.title,
    this.duration,
  });
}
