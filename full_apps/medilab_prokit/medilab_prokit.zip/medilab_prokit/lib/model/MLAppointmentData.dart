class MLAppointmentData {
  String? service;
  String? date;
  String? month;
  String? doctor;
  String? patient;
  String? department;

  MLAppointmentData({this.service, this.date, this.month, this.doctor, this.patient, this.department});
}
