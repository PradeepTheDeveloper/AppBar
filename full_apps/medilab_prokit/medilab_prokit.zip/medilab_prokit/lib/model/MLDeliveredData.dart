class MLDeliveredData {
  String? imageOne;
  String? imageTwo;
  String? status;
  String? medicineOne;
  String? medicineTwo;

  MLDeliveredData({this.imageOne, this.imageTwo, this.status, this.medicineOne, this.medicineTwo});
}
