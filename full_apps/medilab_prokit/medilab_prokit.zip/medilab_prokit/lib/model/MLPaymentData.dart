class MLPaymentData {
  String? image;
  String? title;

  MLPaymentData({this.image, this.title});
}
