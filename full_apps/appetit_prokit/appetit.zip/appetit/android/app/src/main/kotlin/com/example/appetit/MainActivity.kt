package com.example.appetit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
