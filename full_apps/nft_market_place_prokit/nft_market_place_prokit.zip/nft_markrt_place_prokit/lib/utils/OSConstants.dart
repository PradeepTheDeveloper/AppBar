const image1 = 'https://i.imgur.com/OB0y6MR.jpg'; //Landscape image
const image2 = 'https://i.imgur.com/CzXTtJV.jpg'; //Landscape image
const image3 = 'https://farm2.staticflickr.com/1533/26541536141_41abe98db3_z_d.jpg'; //Landscape image
const image4 = 'https://farm9.staticflickr.com/8505/8441256181_4e98d8bff5_z_d.jpg'; // Landscape image
const image5 = 'https://picsum.photos/id/237/200/300'; //potrait image
const image6 = 'https://picsum.photos/seed/picsum/200/300'; // potrait image
const image7 = 'https://picsum.photos/200/300';
const image8 = 'https://picsum.photos/200/300/?blur=2';
const image9 = 'https://picsum.photos/200/300?grayscale';
const image10 = 'https://picsum.photos/id/870/200/300?grayscale&blur=2';

const prokitBaseUrl = 'https://assets.iqonic.design/old-themeforest-images/prokit';

const osImageBaseUrl = '$prokitBaseUrl/images/opensea_images/';
