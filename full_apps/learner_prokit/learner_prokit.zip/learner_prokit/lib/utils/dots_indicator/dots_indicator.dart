library dots_indicator;

export 'src/dots_decorator.dart' show DotsDecorator;
export 'src/dots_indicator.dart' show DotsIndicator;
