import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:musicpodcast_prokit/component/MPDrawerScreen.dart';
import 'package:musicpodcast_prokit/models/MusicModel.dart';
import 'package:musicpodcast_prokit/screen/MPAlbumsScreen.dart';
import 'package:musicpodcast_prokit/screen/MPDiscoverScreen.dart';
import 'package:musicpodcast_prokit/screen/MPProfileScreen.dart';
import 'package:musicpodcast_prokit/screen/MPSongTypeScreen.dart';
import 'package:musicpodcast_prokit/utils/MPColors.dart';
import 'package:musicpodcast_prokit/utils/MPDataGenerator.dart';
import 'package:musicpodcast_prokit/utils/MPImages.dart';
import 'package:musicpodcast_prokit/utils/MPWidget.dart';

class MPDashboardScreen extends StatefulWidget {
  static String tag = '/MPDashboardScreen';

  @override
  MPDashboardScreenState createState() => MPDashboardScreenState();
}

class MPDashboardScreenState extends State<MPDashboardScreen> {
  TextEditingController searchController = TextEditingController();

  List<DrawerList> drawerList = getDrawerList();

  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  int currentIndex = 0;

  final tabs = [
    MPDiscoverScreen(),
    MPSongTypeScreen(),
    MPAlbumsScreen(isTab: true),
    MPProfileScreen(isTab: false),
  ];

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    //
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: mpAppBackGroundColor,
        key: _scaffoldKey,
        appBar: AppBar(
          elevation: 0.0,
          backgroundColor: mpAppBackGroundColor,
          leading: IconButton(
            icon: Icon(Icons.menu, color: white),
            onPressed: () {
              _scaffoldKey.currentState!.openDrawer();
            },
          ),
          title: Container(
            height: 40,
            width: context.width(),
            child: searchAlbumTextFiled(context),
          ),
          actions: [
            Container(
              width: 40,
              height: 40,
              margin: EdgeInsets.only(right: 16),
              decoration: boxDecorationWithShadow(
                boxShape: BoxShape.circle,
                decorationImage: DecorationImage(image: Image.network(mpImages_4).image, fit: BoxFit.cover),
              ),
            )
          ],
        ),
        drawer: DrawerScreen(),
        body: Stack(
          children: [
            tabs[currentIndex],
            Positioned(
              left: 0,
              right: 0,
              bottom: 4,
              child: BottomNavigationBar(
                selectedItemColor: mpAppButtonColor,
                unselectedItemColor: Colors.white,
                type: BottomNavigationBarType.fixed,
                backgroundColor: mpBottomBgColor.withOpacity(0.9),
                currentIndex: currentIndex,
                items: [
                  BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Discover'),
                  BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Song'),
                  BottomNavigationBarItem(icon: Icon(Icons.album), label: 'Albums'),
                  BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
                ],
                onTap: (index) {
                  currentIndex = index;
                  setState(() {});
                },
              ).cornerRadiusWithClipRRect(30).paddingOnly(left: 16, right: 16, bottom: 8),
            )
          ],
        ),
      ),
    );
  }
}
