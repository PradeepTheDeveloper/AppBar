import 'package:flutter/cupertino.dart';

class EAActivityModel{
  String? image;
  String? time;
  String? subtime;
  String? name;
  String? subtitle;
  IconData? icon;

  EAActivityModel({this.image, this.time, this.subtime, this.name, this.subtitle, this.icon});
}