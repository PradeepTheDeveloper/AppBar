String name = "John Smith";
String email = "johnsmith@gmail.com";
String about = "I am great to accept any service at free of cost. Provider please contact me if any issue is faced. Thank you.";

String get getName => name;

String get getEmail => email;

String get getAbout => about;

void setName(String value) {
  name = value;
}

void setEmail(String value) {
  email = value;
}

void setAbout(String value) {
  about = value;
}
