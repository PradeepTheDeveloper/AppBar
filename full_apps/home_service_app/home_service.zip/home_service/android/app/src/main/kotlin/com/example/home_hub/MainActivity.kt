package com.example.home_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
