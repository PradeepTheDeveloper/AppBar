package com.example.medium_prokit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
