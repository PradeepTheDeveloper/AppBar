class ConnectionType {
  String? connectionItemTitle;

  ConnectionType({required this.connectionItemTitle});
}
