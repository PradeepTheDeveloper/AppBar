class LiveVideoModel {
  String? image;
  String? title;
  String? message;
  String? status;

  LiveVideoModel({
    this.image,
    this.title,
    this.message,
    this.status,
  });
}
