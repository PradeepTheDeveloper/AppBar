class SDLessonDetailModel {
  String? image;
  String? subjectName;
  String? totalChapter;
  double? status;
  String? backgroundImages;

  SDLessonDetailModel({
    this.image,
    this.subjectName,
    this.totalChapter,
    this.status,
    this.backgroundImages,
  });
}
