class LessonsModel {
  String? image;
  String? title;
  String? backgroundImages;

  LessonsModel({
    this.image,
    this.title,
    this.backgroundImages,
  });
}
