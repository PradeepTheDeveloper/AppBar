

class SDNotidicationModel {
  String? images;
  String? notificationmessage;
  String? time;
  bool? dot = false;

  SDNotidicationModel({
    this.images,
    this.notificationmessage,
    this.time,
    this.dot,
  });
}
