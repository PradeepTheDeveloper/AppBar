const lsWalkSubTitle = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    ' Phasellus facilisis sit amet magna posuere ornare. In tellus turpis, laoreet'
    ' eu nisi in, volutpat malesuada nulla.';

const isDarkModeOnPref = 'isDarkModeOnPref';
const appName = "Laundry Service App";
