class BMServiceListModel{

  String name;
  String cost;
  String time;

  BMServiceListModel({required this.name,required this.cost,required this.time});

}